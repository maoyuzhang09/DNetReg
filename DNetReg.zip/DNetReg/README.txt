README - R code for DNetReg
October 2023


The downloaded file 'DNetReg.R' has the main function of DNetReg, EdgeReg and DEdgeReg.  An example of the simulation in the paper is included at the end of the file.